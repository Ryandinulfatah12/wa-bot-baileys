const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const qrcode = require('qrcode');
const fs = require('fs');
const cleanPhoneNumber = require('./component/cleanPhoneNumber');

require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

app.set('view engine', 'ejs');
app.use(express.json());
app.use(express.static(__dirname + '/public'));

const connectedDevices = {};

io.on('connection', (socket) => {
    console.log(process.env.URL_LOCAL);

    const uuid = socket.handshake.query.uuid;
    const projectId = socket.handshake.query.projectId;

    if (uuid || projectId) {
        if (!connectedDevices[projectId]) {
            connectedDevices[projectId] = { socket, connected: false, uuid, projectId };
            connectionLogicMultiDevice(projectId);
        }

        socket.on('disconnect', () => {
            if (connectedDevices[projectId]) {
                connectedDevices[projectId].connected = false;
                console.log(`Device with projectId ${projectId} disconnected`);
            }
        });
    }
});

app.get('/', (req, res) => {
    const uuid = req.query.uuid;
    const projectId = req.query.projectId;
    res.render('index');
});

app.post('/send-message', async (req, res) => {
    const { projectId, phoneNumber, message } = req.body;

    if (!projectId || !phoneNumber || !message) {
        return res.status(400).send('Missing required fields');
    }

    const device = connectedDevices[projectId];
    if (!device || !device.connected || !device.sock) {
        return res.status(404).send('Device not connected');
    }

    // const cleanedPhoneNumber = cleanPhoneNumber(phoneNumber);
    // console.log("phoneNumber => " + phoneNumber)
    // console.log("cleanedPhoneNumber => " + cleanedPhoneNumber)

    try {
        await device.sock.sendMessage(`${phoneNumber}@s.whatsapp.net`, { text: message });
        res.status(200).send('Message sent');
    } catch (error) {
        console.error('Error sending message:', error);
        res.status(500).send('Failed to send message');
    }
});


app.get('/check-connection', (req, res) => {
    const { projectId } = req.query;

    if (!projectId) {
        return res.status(400).send('Missing projectId');
    }

    const device = connectedDevices[projectId];
    if (device && device.connected) {
        return res.status(200).send('Device is connected');
    } else {
        return res.status(404).send('Device not connected');
    }
});

const {
    DisconnectReason,
    useMultiFileAuthState
} = require('@whiskeysockets/baileys');
const makeWASocket = require('@whiskeysockets/baileys').default;

async function connectionLogicMultiDevice(projectId) {
    const { state, saveCreds } = await useMultiFileAuthState(`auth_info_baileys_${projectId}`);
    const sock = makeWASocket({
        printQRInTerminal: false,
        auth: state
    });
    connectedDevices[projectId].sock = sock;

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        console.log('connection', connection);

        if (qr) {
            try {
                const qrCodeDataURL = await qrcode.toDataURL(qr);
                connectedDevices[projectId].socket.emit('qrCode', qrCodeDataURL);
                connectedDevices[projectId].socket.emit('message', 'Waiting to connect');
            } catch (error) {
                console.error('Error generating QR code:', error);
            }
        }

        if (connection === 'open') {
            connectedDevices[projectId].socket.emit('message', 'Connected');
            connectedDevices[projectId].connected = true;
            console.log(`Device with projectId ${projectId} connected`);
        }

        if (connection === 'close') {
            connectedDevices[projectId].connected = false;
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            const shouldRescan = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;

            if (shouldReconnect) {
                console.log(`Reconnecting device with projectId ${projectId}`);
                connectionLogicMultiDevice(projectId);
            }

            if (shouldRescan) {
                try {
                    fs.unlinkSync(`auth_info_baileys_${projectId}/creds.json`);
                    console.log(`Rescanning device with projectId ${projectId}`);
                    connectionLogicMultiDevice(projectId);
                } catch (error) {
                    console.error('Error clearing creds.json:', error);
                }
            }
        }
    });

    sock.ev.on('creds.update', saveCreds);
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
